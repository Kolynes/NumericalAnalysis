this is the solution to level 1
it is written in python (version 3.6.8)

requirements: 
    matplotlib
        # pip install matplotlib #